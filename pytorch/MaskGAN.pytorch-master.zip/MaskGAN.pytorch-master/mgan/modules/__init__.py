from .trainer import MGANTrainer


